package com.aaa.dao;

import java.util.List;

import com.aaa.entity.User;
public interface UserDao {
	List login(User user);


}
