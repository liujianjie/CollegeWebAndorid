package com.aaa.biz;

import java.util.List;

import com.aaa.entity.User;

public interface UserBiz {
	List login(User user);
}
