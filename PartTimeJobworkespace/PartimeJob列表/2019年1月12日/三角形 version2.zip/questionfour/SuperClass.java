package questionfour;

public class SuperClass {
	public void print(){
		System.out.println("Superclass��print()");
	}
}
