package questionthree;

public class Triger extends Animal{
	public static void main(String[] args) {
		Animal tg = new Triger();
		tg.getfly();
		tg.setName("�ϻ�");
		System.out.println(tg.getName());
	}
}
