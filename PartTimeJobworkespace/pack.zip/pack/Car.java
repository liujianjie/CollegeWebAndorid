package pack;

import java.util.Objects;

public class Car extends Vehicle{
	private String manufacturer;
	private String timeOfPurchase;

	public Car(String manufacturer, String timeOfPurchase,String colour, double weight, double speed) {
		super(colour, weight, speed);
		// TODO Auto-generated constructor stub
		this.manufacturer = manufacturer;
		this.timeOfPurchase = timeOfPurchase;
	}
	
	@Override
	public String manufactureDate() {
		// TODO Auto-generated method stub
		return timeOfPurchase;
	}
	
	@Override
	public boolean equals(Object obj) {
		// ���Ϊͬһ����Ĳ�ͬ����,����ͬ
        if (this == obj) {
            return true;
        }
        // �������Ķ���Ϊ��,�򷵻�false
        if (obj == null) {
            return false;
        }

        // ����������ڲ�ͬ������,�������
        if (getClass() != obj.getClass()) {
            return false;
        }

        // ������ͬ, �Ƚ������Ƿ���ͬ
        Car other = (Car) obj;

        return Objects.equals(manufacturer, other.manufacturer) && timeOfPurchase == other.timeOfPurchase;
	}
	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getTimeOfPurchase() {
		return timeOfPurchase;
	}

	public void setTimeOfPurchase(String timeOfPurchase) {
		this.timeOfPurchase = timeOfPurchase;
	}
}
