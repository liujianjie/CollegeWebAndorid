package pack;

public abstract class Vehicle {
	private String colour;
	private double weight;
	private double speed;
	
	public Vehicle(String colour, double weight, double speed) {
		super();
		this.colour = colour;
		this.weight = weight;
		this.speed = speed;
	}
	public abstract String manufactureDate();
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public double getSpeed() {
		return speed;
	}
	public void setSpeed(double speed) {
		this.speed = speed;
	}
}
