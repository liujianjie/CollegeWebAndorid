package com.tank.configure;

/**
 * Author:
 * DataTime:
 * Effect:һЩ������
 * */
public class Param {
	public static int TANK_UP=1;
	public static int TANK_DOWN=2;
	public static int TANK_LEFT=3;
	public static int TANK_RIGHT=4;
}
