package net.simonvt.menudrawer.samples;

public class Item {

    String mTitle;
    int mIconRes;

    Item(String title, int iconRes) {
        mTitle = title;
        mIconRes = iconRes;
    }
}
