create sequence seq_review_jerry 
increment by 1
start with 1;

create sequence seq_review_jerry_order 
increment by 1
start with 10000