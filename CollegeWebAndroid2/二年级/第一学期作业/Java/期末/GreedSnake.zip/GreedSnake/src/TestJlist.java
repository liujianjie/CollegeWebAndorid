import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JList;

public class TestJlist extends JFrame{
	String st[] = {"1","2","3"};
	public TestJlist(){
		JList<Object> jl = new JList<Object>(st);
		add(jl);
		setVisible(true);
		setSize(new Dimension(300,200));
		int a = 0;
		jl.setSelectedIndex(a + 3);
		System.out.println(a);
	}
	public static void main(String[] args) {
		new TestJlist();
	}
}
