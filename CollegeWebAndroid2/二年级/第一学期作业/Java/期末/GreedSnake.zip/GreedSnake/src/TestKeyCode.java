import java.awt.event.KeyEvent;

public class TestKeyCode {
	public static void main(String[] args) {
		System.out.println(KeyEvent.VK_2);
		System.out.println(KeyEvent.VK_3);
		char c = 'h';
		System.out.println((int)(c - '0'));
		
//		int i = 1;
//		char cc = (char)(i + '0');
//		System.out.println((cc));
//		String n = new String("\n");
//		System.out.println(n.length());
	}
}
