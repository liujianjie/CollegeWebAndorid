import javax.swing.JFrame;

import org.w3c.dom.events.MouseEvent;

public class T1 extends JFrame {

}
