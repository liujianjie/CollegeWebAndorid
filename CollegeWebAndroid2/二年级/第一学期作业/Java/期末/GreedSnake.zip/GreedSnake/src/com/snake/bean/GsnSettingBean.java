package com.snake.bean;
// ��Ϸ���õ�bean 
public class GsnSettingBean {
	public int isvoice;// �����Ƿ� 0 �أ�1��
	public int computercount;// Ĭ��Ϊ1
	public int language;// 0�����ģ�1��Ӣ��
	
	

	public GsnSettingBean(){
		computercount = 1;// Ĭ��һ�� ��һû��ȡ��
		// Ĭ������ �͹أ���ΪintĬ��Ϊ0
	}
	public GsnSettingBean(int v, int c, int l){
		isvoice = v;
		computercount = c;
		language = l;
	}
	@Override
	public String toString() {
		return "isvoice="+isvoice+"&computercount=" + computercount+"&language="+language;
	}
	
	public int getIsvoice() {
		return isvoice;
	}
	public void setIsvoice(int isvoice) {
		this.isvoice = isvoice;
	}
	public int getComputercount() {
		return computercount;
	}
	public void setComputercount(int computercount) {
		this.computercount = computercount;
	}
	public int getLanguage() {
		return language;
	}
	public void setLanguage(int language) {
		this.language = language;
	}
	public static void main(String[] args) {
		GsnSettingBean s = new GsnSettingBean();
		s.computercount = 2;
		System.out.println(s);
	}
}
