package com.snake.iomap;
import java.io.File;
import java.io.FileInputStream;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;

import com.snake.mgameconfig.GsnMainGameConstants;

import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

public class GsnWav {
	private FileInputStream filein;
	private AudioStream as;
	private File file;
	
	public void playWavfile(String filename){ //�򵥿� ���� �����ǿ��ܻ���ڴ�й¶
		try {  
            // 1.wav �ļ�����java project / music����  JCREATOR��������д../music/��eclipse��music/
            filein = new FileInputStream(GsnMainGameConstants.wavpath+"/"+filename); 
            as = new AudioStream(filein);  
            AudioPlayer.player.start(as);  
            
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
	}
	
	public void playWavfileSave(String filename) { // �ܸ��ÿ����� ����������ڴ�й¶������������Ϊ�ֽڶ�ȡ while
		try{
			file = new File(GsnMainGameConstants.wavpath+"/"+filename); //�ļ���ַ
			AudioInputStream ais = AudioSystem.getAudioInputStream(file);
			AudioFormat af = ais.getFormat();
			SourceDataLine sdl = null;
			DataLine.Info dinfo = new DataLine.Info(SourceDataLine.class, af);
			sdl = (SourceDataLine) AudioSystem.getLine(dinfo);
			sdl.open(af);
			byte[] lbytes = new byte[sdl.available()];
			int lReadBytes = 0;
			sdl.start();
			while (lReadBytes != -1) {
				lReadBytes = ais.read(lbytes, 0, lbytes.length);
				if (lReadBytes > 0) {
					sdl.write(lbytes, 0, lReadBytes);
				}
			}
			//�ر���
			ais.close();
			sdl.close();
			
		} catch(Exception ex){
			ex.printStackTrace();
		}
	}
//	public static void main(String[] args) {
//		GsnWav te = new GsnWav();
//		te.playWavfile("dead.wav");
//		te.playWavfileSave("eatfood.wav");
//	}
}
